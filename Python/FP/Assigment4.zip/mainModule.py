#Main Module

from testsModule import runAllTests
from UIModule import run

def mainFunction():
    runAllTests()
    run()

if __name__ == '__main__':
    mainFunction()
    